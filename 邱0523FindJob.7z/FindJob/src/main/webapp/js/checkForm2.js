function checkForm2() {
    let checkResult = true;


   i
   
   
   
   
   

}



